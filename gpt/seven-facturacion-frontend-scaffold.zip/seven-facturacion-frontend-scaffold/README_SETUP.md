# Seven Facturación UI (Angular + DevExtreme) — Scaffold (Copy-Into Project)

Este paquete NO es un proyecto Angular completo (no trae `package.json`, `angular.json`, etc.).
La idea es que lo copies dentro de un proyecto Angular creado con tu Angular CLI (20.3.7).

---

## 1) Crear el proyecto Angular (standalone + routing)

> Recomendación: standalone es el camino moderno y simple en Angular (v15+).  
> Este scaffold está pensado para Angular 20+.

```bash
# 1) Crear el proyecto
ng new seven-facturacion-ui --standalone --routing --style=scss --ssr=false

cd seven-facturacion-ui
```

---

## 2) Agregar DevExtreme

DevExpress recomienda un “one-command setup” para agregar DevExtreme al proyecto:

```bash
npx -p devextreme-cli devextreme add devextreme-angular
```

Si prefieres manual:

```bash
npm i devextreme devextreme-angular
```

> El comando de DevExtreme también configura estilos/archivos por ti.

---

## 3) Configurar Proxy (para evitar CORS en dev)

Copia `proxy.conf.json` (incluido en este scaffold) a la raíz del proyecto Angular.

Luego, en `package.json` agrega/ajusta el script de start:

```json
{
  "scripts": {
    "start": "ng serve --proxy-config proxy.conf.json"
  }
}
```

---

## 4) Copiar el código del scaffold al proyecto

Copia el contenido de:

- `src/`  -> a `seven-facturacion-ui/src/`
- `proxy.conf.json` -> a la raíz del proyecto Angular
- (opcional) revisa `angular.json` y valida que DevExtreme CSS quede incluido

---

## 5) Ejecutar

Asegúrate de que tu Backend esté arriba en `http://localhost:5000` (según la doc del backend).

```bash
npm start
```

Abrir:
- `http://localhost:4200`

---

## 6) Qué incluye este scaffold

- Listado de facturas (DataGrid DevExtreme)
- Crear factura (Popup + Form + DataGrid para detalles)
- “Editar” (mínimo) = cambiar estado de factura (PATCH), porque en la API documentada no aparece un PUT de factura.
- Servicios REST tipados para:
  - `/api/Facturas`
  - `/api/Clientes`
  - `/api/Productos`

---

## 7) URLs del backend (importante)

Este scaffold asume que el backend expone la API en:

- `http://localhost:5000/api`

y que usarás proxy en Angular para consumirla como:

- `/api/...`

Si cambias el puerto o dominio, edita:
- `src/environments/environment.ts`
- `proxy.conf.json`

