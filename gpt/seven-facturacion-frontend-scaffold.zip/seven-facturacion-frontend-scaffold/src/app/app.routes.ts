// app.routes.ts
// -----------------------------------------------------------------------------
// Rutas de la aplicación. Mantenemos un routing mínimo.
// -----------------------------------------------------------------------------

import { Routes } from '@angular/router';
import { FacturasPageComponent } from './features/facturas/pages/facturas-page.component';

export const routes: Routes = [
  // Home => Facturas
  { path: '', pathMatch: 'full', redirectTo: 'facturas' },

  // Feature route
  { path: 'facturas', component: FacturasPageComponent },

  // Fallback
  { path: '**', redirectTo: 'facturas' }
];
