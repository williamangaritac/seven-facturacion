// api-client.ts
// -----------------------------------------------------------------------------
// Cliente HTTP delgado (KISS) para centralizar:
// - baseUrl del API
// - construcción de URLs
// - métodos CRUD comunes
//
// Beneficios (DRY/SOLID):
// - Un solo punto para cambiar baseUrl o headers globales.
// - Servicios por feature (Invoices/Clients/Products) quedan pequeños y claros.
// -----------------------------------------------------------------------------

import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { API_BASE_URL } from '../tokens/api-base-url.token';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ApiClient {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = inject(API_BASE_URL);

  /**
   * Construye una URL del API sin duplicar slash.
   * Ej: buildUrl('Facturas') => /api/Facturas (cuando baseUrl = '/api')
   */
  private buildUrl(path: string): string {
    const normalizedBase = this.baseUrl.replace(/\/+$/, '');
    const normalizedPath = path.replace(/^\/+/, '');
    return `${normalizedBase}/${normalizedPath}`;
  }

  /** GET tipado */
  get<T>(path: string, params?: Record<string, string | number | boolean | undefined>): Observable<T> {
    const url = this.buildUrl(path);
    const httpParams = this.toHttpParams(params);
    return this.http.get<T>(url, { params: httpParams });
  }

  /** POST tipado */
  post<TResponse, TBody>(path: string, body: TBody): Observable<TResponse> {
    const url = this.buildUrl(path);
    return this.http.post<TResponse>(url, body);
  }

  /** PATCH tipado */
  patch<TResponse, TBody>(path: string, body: TBody): Observable<TResponse> {
    const url = this.buildUrl(path);
    return this.http.patch<TResponse>(url, body);
  }

  /** DELETE tipado */
  delete(path: string): Observable<void> {
    const url = this.buildUrl(path);
    return this.http.delete<void>(url);
  }

  private toHttpParams(params?: Record<string, string | number | boolean | undefined>): HttpParams {
    let hp = new HttpParams();
    if (!params) return hp;

    for (const [key, value] of Object.entries(params)) {
      if (value === undefined) continue;
      hp = hp.set(key, String(value));
    }
    return hp;
  }
}
