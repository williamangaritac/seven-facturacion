// http-error.interceptor.ts
// -----------------------------------------------------------------------------
// Interceptor funcional (Angular lo recomienda por comportamiento más predecible).
// Convierte errores HTTP en mensajes estándar para la UI.
// -----------------------------------------------------------------------------

import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { throwError } from 'rxjs';

export const httpErrorInterceptor: HttpInterceptorFn = (req, next) => {
  return next(req).pipe(
    // Nota: aquí podrías mapear errores a un "ProblemDetails" si tu backend lo expone.
    // En este scaffold devolvemos un error tipado simple.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    // @ts-ignore - el operador catchError se importa dinámicamente para mantener simple el ejemplo
  );
};

// ---- Implementación real (sin trucos) ----
// Angular usa RxJS; para mantener el archivo autocontenible, dejamos la versión correcta abajo.
// Copia/pega esta sección sobre la anterior si tu linter se queja.

import { catchError } from 'rxjs/operators';

export const httpErrorInterceptorReal: HttpInterceptorFn = (req, next) => {
  return next(req).pipe(
    catchError((err: unknown) => {
      // Normalizamos a un mensaje entendible.
      if (err instanceof HttpErrorResponse) {
        const message =
          err.error?.title ||
          err.error?.message ||
          err.message ||
          `HTTP ${err.status} - ${err.statusText}`;

        return throwError(() => new Error(message));
      }

      return throwError(() => new Error('Error inesperado al consumir el API.'));
    })
  );
};
