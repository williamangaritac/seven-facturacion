// factura.models.ts
// -----------------------------------------------------------------------------
// Facturas y DTOs de request/response.
// Nota: el backend calcula subtotal/impuesto/total.
// -----------------------------------------------------------------------------

export type EstadoFactura = 'PENDIENTE' | 'PAGADA' | 'ANULADA';

export interface DetalleFacturaDto {
  id: number;
  productoId: number;
  nombreProducto: string;
  cantidad: number;
  precioUnitario: number;
  subtotal: number;
}

export interface FacturaDto {
  id: number;
  numeroFactura: string;
  clienteId: number;
  nombreCliente: string;
  fecha: string; // ISO datetime
  subtotal: number;
  impuesto: number;
  total: number;
  estado: EstadoFactura;
  detalles: DetalleFacturaDto[];
}

export interface CrearFacturaDetalleDto {
  productoId: number;
  cantidad: number;
}

export interface CrearFacturaDto {
  clienteId: number;
  detalles: CrearFacturaDetalleDto[];
}

export interface ActualizarEstadoFacturaDto {
  estado: EstadoFactura;
}
