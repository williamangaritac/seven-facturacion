// producto.models.ts
// -----------------------------------------------------------------------------
// Modelos TypeScript basados en la doc del backend.
// -----------------------------------------------------------------------------

export interface ProductoDto {
  id: number;
  codigo: string;
  nombre: string;
  descripcion?: string | null;
  precio: number;
  stock: number;
  activo: boolean;
  tieneStockBajo: boolean;
  estaAgotado: boolean;
}
