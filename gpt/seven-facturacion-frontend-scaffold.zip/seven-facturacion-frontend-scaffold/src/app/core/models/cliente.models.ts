// cliente.models.ts
// -----------------------------------------------------------------------------
// Modelos TypeScript basados en la documentación del backend.
// Mantenerlos en /core/models evita duplicación y facilita el reuso.
// -----------------------------------------------------------------------------

export interface ClienteDto {
  id: number;
  nombre: string;
  apellido: string;
  nombreCompleto: string;
  correoElectronico: string;
  telefono?: string | null;
  fechaNacimiento: string; // ISO date (YYYY-MM-DD)
  edad: number;
  direccion?: string | null;
  activo: boolean;
}
