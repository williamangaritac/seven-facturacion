// api-base-url.token.ts
// -----------------------------------------------------------------------------
// Un InjectionToken evita "magic strings" y facilita test/mocking.
// La app lo configura en app.config.ts.
// -----------------------------------------------------------------------------

import { InjectionToken } from '@angular/core';

export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL');
