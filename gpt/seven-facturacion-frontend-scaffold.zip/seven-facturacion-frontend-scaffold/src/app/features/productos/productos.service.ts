// productos.service.ts
// -----------------------------------------------------------------------------
// Servicio de acceso a /api/Productos.
// -----------------------------------------------------------------------------

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../../core/http/api-client';
import { ProductoDto } from '../../core/models/producto.models';

@Injectable({ providedIn: 'root' })
export class ProductosService {
  constructor(private readonly api: ApiClient) {}

  getAll(): Observable<ProductoDto[]> {
    return this.api.get<ProductoDto[]>('Productos');
  }
}
