// facturas.service.ts
// -----------------------------------------------------------------------------
// Servicio de acceso a /api/Facturas.
// -----------------------------------------------------------------------------

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../../core/http/api-client';
import { ActualizarEstadoFacturaDto, CrearFacturaDto, FacturaDto } from '../../core/models/factura.models';

@Injectable({ providedIn: 'root' })
export class FacturasService {
  constructor(private readonly api: ApiClient) {}

  getAll(): Observable<FacturaDto[]> {
    return this.api.get<FacturaDto[]>('Facturas');
  }

  getById(id: number): Observable<FacturaDto> {
    return this.api.get<FacturaDto>(`Facturas/${id}`);
  }

  create(dto: CrearFacturaDto): Observable<FacturaDto> {
    return this.api.post<FacturaDto, CrearFacturaDto>('Facturas', dto);
  }

  /**
   * En la documentación disponible, la “edición” de factura aparece como:
   * PATCH /api/Facturas/{id}/estado
   */
  updateEstado(id: number, dto: ActualizarEstadoFacturaDto): Observable<FacturaDto> {
    return this.api.patch<FacturaDto, ActualizarEstadoFacturaDto>(`Facturas/${id}/estado`, dto);
  }

  delete(id: number): Observable<void> {
    return this.api.delete(`Facturas/${id}`);
  }
}
