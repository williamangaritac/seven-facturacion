// facturas-page.component.ts
// -----------------------------------------------------------------------------
// Página principal del módulo "Facturas":
// - Lista de facturas (DataGrid)
// - Crear factura (Popup)
// - Editar estado (Popup)
// -----------------------------------------------------------------------------

import { Component, OnInit, signal } from '@angular/core';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { DxButtonModule, DxDataGridModule, DxFormModule, DxPopupModule, DxSelectBoxModule, DxNumberBoxModule } from 'devextreme-angular';

import { FacturasService } from '../facturas.service';
import { ClientesService } from '../../clientes/clientes.service';
import { ProductosService } from '../../productos/productos.service';

import { ClienteDto } from '../../../core/models/cliente.models';
import { ProductoDto } from '../../../core/models/producto.models';
import { CrearFacturaDto, EstadoFactura, FacturaDto } from '../../../core/models/factura.models';

type FacturaDetalleDraft = {
  productoId: number | null;
  cantidad: number;
};

@Component({
  selector: 'app-facturas-page',
  standalone: true,
  imports: [
    CommonModule,
    DxDataGridModule,
    DxButtonModule,
    DxPopupModule,
    DxFormModule,
    DxSelectBoxModule,
    DxNumberBoxModule,
    CurrencyPipe,
    DatePipe
  ],
  templateUrl: './facturas-page.component.html'
})
export class FacturasPageComponent implements OnInit {
  // ---------------------------------------------------------------------------
  // Estado de UI (usando signals para simpleza; evitamos "state managers" extra).
  // ---------------------------------------------------------------------------

  readonly loading = signal<boolean>(false);
  readonly errorMessage = signal<string | null>(null);

  readonly facturas = signal<FacturaDto[]>([]);
  readonly clientes = signal<ClienteDto[]>([]);
  readonly productos = signal<ProductoDto[]>([]);

  // Popup Crear
  readonly crearPopupVisible = signal<boolean>(false);

  // Draft de creación (se mapea al CrearFacturaDto)
  readonly crearClienteId = signal<number | null>(null);
  readonly crearDetalles = signal<FacturaDetalleDraft[]>([
    { productoId: null, cantidad: 1 }
  ]);

  // Popup Editar Estado
  readonly editarEstadoPopupVisible = signal<boolean>(false);
  readonly editarFacturaSeleccionada = signal<FacturaDto | null>(null);
  readonly editarEstado = signal<EstadoFactura>('PENDIENTE');

  readonly estados: EstadoFactura[] = ['PENDIENTE', 'PAGADA', 'ANULADA'];

  constructor(
    private readonly facturasService: FacturasService,
    private readonly clientesService: ClientesService,
    private readonly productosService: ProductosService
  ) {}

  ngOnInit(): void {
    this.cargarCatalogosYFacturas();
  }

  // ---------------------------------------------------------------------------
  // Carga inicial
  // ---------------------------------------------------------------------------

  private cargarCatalogosYFacturas(): void {
    this.loading.set(true);
    this.errorMessage.set(null);

    // KISS: 3 requests en paralelo, y al final refrescamos la grilla.
    // En una app mayor podrías usar forkJoin con manejo de fallas por llamada.
    this.clientesService.getAll().subscribe({
      next: (data) => this.clientes.set(data),
      error: (e: Error) => this.errorMessage.set(e.message)
    });

    this.productosService.getAll().subscribe({
      next: (data) => this.productos.set(data),
      error: (e: Error) => this.errorMessage.set(e.message)
    });

    this.refrescarFacturas();
  }

  refrescarFacturas(): void {
    this.loading.set(true);
    this.errorMessage.set(null);

    this.facturasService.getAll().subscribe({
      next: (data) => {
        this.facturas.set(data);
        this.loading.set(false);
      },
      error: (e: Error) => {
        this.errorMessage.set(e.message);
        this.loading.set(false);
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Crear factura
  // ---------------------------------------------------------------------------

  abrirCrear(): void {
    this.crearClienteId.set(null);
    this.crearDetalles.set([{ productoId: null, cantidad: 1 }]);
    this.crearPopupVisible.set(true);
  }

  agregarLineaDetalle(): void {
    this.crearDetalles.update((rows) => [...rows, { productoId: null, cantidad: 1 }]);
  }

  eliminarLineaDetalle(index: number): void {
    this.crearDetalles.update((rows) => rows.filter((_, i) => i !== index));
  }

  guardarFactura(): void {
    // Validación mínima (KISS). La validación real debe vivir en backend también.
    const clienteId = this.crearClienteId();
    if (!clienteId) {
      this.errorMessage.set('Selecciona un cliente.');
      return;
    }

    const detallesLimpios = this.crearDetalles()
      .filter((d) => !!d.productoId && d.cantidad > 0)
      .map((d) => ({ productoId: d.productoId as number, cantidad: d.cantidad }));

    if (detallesLimpios.length === 0) {
      this.errorMessage.set('Agrega al menos un producto con cantidad válida.');
      return;
    }

    const dto: CrearFacturaDto = {
      clienteId,
      detalles: detallesLimpios
    };

    this.loading.set(true);
    this.errorMessage.set(null);

    this.facturasService.create(dto).subscribe({
      next: () => {
        this.crearPopupVisible.set(false);
        this.refrescarFacturas();
      },
      error: (e: Error) => {
        this.errorMessage.set(e.message);
        this.loading.set(false);
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Editar estado (la API documentada expone PATCH estado, no PUT de factura)
  // ---------------------------------------------------------------------------

  abrirEditarEstado(factura: FacturaDto): void {
    this.editarFacturaSeleccionada.set(factura);
    this.editarEstado.set(factura.estado);
    this.editarEstadoPopupVisible.set(true);
  }

  guardarEstado(): void {
    const factura = this.editarFacturaSeleccionada();
    if (!factura) return;

    this.loading.set(true);
    this.errorMessage.set(null);

    this.facturasService.updateEstado(factura.id, { estado: this.editarEstado() }).subscribe({
      next: () => {
        this.editarEstadoPopupVisible.set(false);
        this.refrescarFacturas();
      },
      error: (e: Error) => {
        this.errorMessage.set(e.message);
        this.loading.set(false);
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Helpers de UI
  // ---------------------------------------------------------------------------

  getNombreProducto(productoId: number): string {
    return this.productos().find((p) => p.id === productoId)?.nombre ?? `Producto ${productoId}`;
  }

  // Para DataGrid: permite tener un "row key" estable en draft
  trackByIndex = (index: number): number => index;
}
