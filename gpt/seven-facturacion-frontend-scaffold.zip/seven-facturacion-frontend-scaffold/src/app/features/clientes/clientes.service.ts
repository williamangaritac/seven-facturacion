// clientes.service.ts
// -----------------------------------------------------------------------------
// Servicio de acceso a /api/Clientes.
// "Single Responsibility": solo conoce operaciones de Clientes.
// -----------------------------------------------------------------------------

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../../core/http/api-client';
import { ClienteDto } from '../../core/models/cliente.models';

@Injectable({ providedIn: 'root' })
export class ClientesService {
  constructor(private readonly api: ApiClient) {}

  getAll(): Observable<ClienteDto[]> {
    return this.api.get<ClienteDto[]>('Clientes');
  }
}
