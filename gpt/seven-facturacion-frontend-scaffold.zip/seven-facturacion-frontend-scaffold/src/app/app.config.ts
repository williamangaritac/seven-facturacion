// app.config.ts
// -----------------------------------------------------------------------------
// En Angular moderno, el bootstrap se configura con ApplicationConfig.
// Aquí centralizamos providers globales.
//
// Docs oficiales:
// - provideHttpClient en app.config.ts
// - Interceptors funcionales recomendados
// -----------------------------------------------------------------------------

import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';

import { routes } from './app.routes';
import { environment } from '../environments/environment';
import { API_BASE_URL } from './core/tokens/api-base-url.token';
import { httpErrorInterceptorReal } from './core/http/http-error.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),

    // HttpClient global + interceptor funcional
    provideHttpClient(
      withInterceptors([httpErrorInterceptorReal])
    ),

    // Base URL del API (inyectable)
    { provide: API_BASE_URL, useValue: environment.apiBaseUrl }
  ]
};
