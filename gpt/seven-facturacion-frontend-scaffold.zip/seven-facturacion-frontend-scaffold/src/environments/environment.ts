// environment.ts
// -----------------------------------------------------------------------------
// Este archivo se reemplaza en build por environment.production.ts.
// Mantén aquí SOLO configuración (sin secretos).
// -----------------------------------------------------------------------------

export const environment = {
  production: false,

  // Usamos proxy en dev (ver proxy.conf.json), por eso el baseUrl es relativo.
  // En producción puedes apuntar a un dominio real.
  apiBaseUrl: '/api'
} as const;
