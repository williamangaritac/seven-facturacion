// environment.production.ts
// -----------------------------------------------------------------------------
// Configuración de producción.
// IMPORTANTE: Ajusta apiBaseUrl para tu despliegue real.
// -----------------------------------------------------------------------------

export const environment = {
  production: true,
  apiBaseUrl: '/api'
} as const;
